CREATE FUNCTION udfProductInYear (
    @model_year varchar(30)
)
RETURNS TABLE
AS
RETURN
    SELECT 
        order_id,
        customer_id,
        store_id,
		staff_id,
		order_date,
		order_status
    FROM
        sales.orders
    WHERE
        order_date = @model_year;


SELECT * from
 udfProductInYear(2018);

 ALTER FUNCTION udfProductInYear (
    @start_date varchar(30),
    @end_date varchar(30)
)
RETURNS TABLE
AS
RETURN
    SELECT 
       order_id,
        customer_id,
        store_id,
		staff_id,
		order_date,
		order_status
    FROM
        sales.orders
    WHERE
        order_date BETWEEN @start_date AND @end_date

SELECT * from
       udfProductInYear(2017,2018)